package pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethods;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class CreateLeadPage extends ProjectSpecificMethods{

	@Given("Enter the companyName as (.*)$")
	public CreateLeadPage enterCompanyName(String cName) {
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(cName);
		return this;

	}
	
	@And("Enter the firstname as (.*)$")
	public CreateLeadPage enterFirstName(String fName) {

		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(fName);
		return this;
	}
	
	
	@And("Enter the lastname as (.*)$")
	public CreateLeadPage enterLastName(String lName) {
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lName);
		return this;

	}
	
	@When("Click on Submit button")
	public ViewLeadsPage clickSubmitButton() {

		driver.findElement(By.name("submitButton")).click();
		return new ViewLeadsPage();
	}

}
