package base;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadExcel;

public class ProjectSpecificMethods extends AbstractTestNGCucumberTests{

	public String excelFilename;
	//public ChromeDriver driver;
	private static final ThreadLocal<RemoteWebDriver>  rd = new ThreadLocal<>();
	
	//setter
	public void setDriver() {
		
        rd.set(new ChromeDriver());
	}
	
	//getter(the current thread's value of this thread-local)
	public RemoteWebDriver getDriver() {
//	 RemoteWebDriver remoteWebDriver = rd.get();
//	 System.out.println(remoteWebDriver);
		
	 return rd.get();
	}
	
	

	@BeforeMethod
	public void preCondition() {
		setDriver();
		getDriver().manage().window().maximize();
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		getDriver().get("http://leaftaps.com/opentaps/control/main");

	}

	@AfterMethod
	public void postCondition() {
		getDriver().quit();
	}
	
	@DataProvider(parallel=true)
	public String[][] sendData() throws IOException {
		return ReadExcel.readExcel(excelFilename);
	}

}
